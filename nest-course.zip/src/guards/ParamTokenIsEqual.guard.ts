import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Observable } from 'rxjs';

@Injectable()
export class IsEqualParamAndTokenIds implements CanActivate {
  constructor(private readonly jwtService: JwtService) {}
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    try {
      const req = context.switchToHttp().getRequest();
      const authHeader = req.headers.authorization;
      const bearer = authHeader.split(' ')[0];
      const token = authHeader.split(' ')[1];
      if (bearer !== 'Bearer' || !token) {
        throw new UnauthorizedException({
          message: "Foydalanuvchi authorizatsiyadan o'tmagandur",
        });
      }
      const user = this.jwtService.verify(token);
      console.log(user);
      console.log(req.params.id);
        if (req.params.id != user.id) {
          console.log("a123");
        throw new HttpException(
          'sizning bunga imkoningiz yoq',
          HttpStatus.BAD_REQUEST,
        );
      }

      return true;
    } catch (error) {
      throw new UnauthorizedException({
        message: "Foydalanuvchi authorizatsiyadan o'tmagan shekilli",
      });
    }
  }
}
